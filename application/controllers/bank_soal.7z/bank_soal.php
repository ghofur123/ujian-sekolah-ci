<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class bank_soal extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->model("crud_function_model");
	}
	public function index(){
	}
	public function load(){
		if(empty($_GET["act"])){
							
		} else {
			if($_GET["act"] == "insert"){
			
				$arrayPost = array(
				"soal" => $this->input->post("soal"),"a" => $this->input->post("a"),"b" => $this->input->post("b"),"c" => $this->input->post("c"),"d" => $this->input->post("d"),"e" => $this->input->post("e"),"ujian_id" => $this->input->post("ujian_id"),"jawaban_soal" => $this->input->post("jawaban_soal"),
				);
				$this->form_validation->set_rules("soal", "soal", "required");$this->form_validation->set_rules("a", "a", "required");$this->form_validation->set_rules("b", "b", "required");$this->form_validation->set_rules("c", "c", "required");$this->form_validation->set_rules("d", "d", "required");$this->form_validation->set_rules("e", "e", "required");$this->form_validation->set_rules("ujian_id", "ujian_id", "required");$this->form_validation->set_rules("jawaban_soal", "jawaban_soal", "required");
				if($this->form_validation->run() == true){
					$this->crud_function_model->insertData("bank_soal", $arrayPost);
					$message =  array(
					"message" => "Data Berhasil Di Simpan"
					);
				} else {
					$message =  array(
					"message" => validation_errors()
					);
				}
				$this->load->view("admin/valids/validationmessage", $message);
			
			} // end insert
			
			else if($_GET["act"] == "load"){
				$queryDataRead = array(
					"tampilData" => $this->crud_function_model->readData("bank_soal", "", "", "id_bank_soal desc"),
					"idDb" => "id_bank_soal"
				);
				$this->load->view("admin/content/bank_soal/table", $queryDataRead);
			} // end load
			else if($_GET["act"] == "delete"){
				
				$this->crud_function_model->deleteData("bank_soal", "id_bank_soal = $_GET[id]");
			} // end delete	
			else if($_GET["act"] == "view"){
				$queryDataRead = array(
					"tampilData" => $this->crud_function_model->readData("bank_soal", "", "id_bank_soal = $_GET[id]", "id_bank_soal desc"),
					"idDb" => "id_bank_soal"
				);	
				echo "<table class='table'>"; 
				foreach($queryDataRead["tampilData"] as $item){
					echo "
					
						<tr>
							<td>soal</td>
							<td>"; echo $item["soal"]; echo "</td>
						</tr>
						
						<tr>
							<td>a</td>
							<td>"; echo $item["a"]; echo "</td>
						</tr>
						
						<tr>
							<td>b</td>
							<td>"; echo $item["b"]; echo "</td>
						</tr>
						
						<tr>
							<td>c</td>
							<td>"; echo $item["c"]; echo "</td>
						</tr>
						
						<tr>
							<td>d</td>
							<td>"; echo $item["d"]; echo "</td>
						</tr>
						
						<tr>
							<td>e</td>
							<td>"; echo $item["e"]; echo "</td>
						</tr>
						
						<tr>
							<td>ujian_id</td>
							<td>"; echo $item["ujian_id"]; echo "</td>
						</tr>
						
						<tr>
							<td>jawaban_soal</td>
							<td>"; echo $item["jawaban_soal"]; echo "</td>
						</tr>
						
					"; 
				}
				echo "</table>";
			} // end view
			else if($_GET["act"] == "viewEdit"){
				$queryDataRead = array(
					"tampilData" => $this->crud_function_model->readData("bank_soal", "", "id_bank_soal = $_GET[id]", "id_bank_soal desc"),
					"idDb" => "id_bank_soal"
				);	
				echo "<table class='table'>"; 
				foreach($queryDataRead["tampilData"] as $item){
					echo "
						<tr>
							<input type='hidden' name='id' class='form-control' style='width:100%;' value='"; echo $item["id_bank_soal"]; echo "' hidden>
						
							<td>soal</td>
							<td>
							
									<input type='text' name='soal' class='form-control' style='width:100%;' value='"; echo $item["soal"]; echo "' >
								
							</td>
						</tr>
						
							<td>a</td>
							<td>
							
									<input type='text' name='a' class='form-control' style='width:100%;' value='"; echo $item["a"]; echo "' >
								
							</td>
						</tr>
						
							<td>b</td>
							<td>
							
									<input type='text' name='b' class='form-control' style='width:100%;' value='"; echo $item["b"]; echo "' >
								
							</td>
						</tr>
						
							<td>c</td>
							<td>
							
									<input type='text' name='c' class='form-control' style='width:100%;' value='"; echo $item["c"]; echo "' >
								
							</td>
						</tr>
						
							<td>d</td>
							<td>
							
									<input type='text' name='d' class='form-control' style='width:100%;' value='"; echo $item["d"]; echo "' >
								
							</td>
						</tr>
						
							<td>e</td>
							<td>
							
									<input type='text' name='e' class='form-control' style='width:100%;' value='"; echo $item["e"]; echo "' >
								
							</td>
						</tr>
						
							<td>ujian_id</td>
							<td>
							
									<input type='text' name='ujian_id' class='form-control' style='width:100%;' value='"; echo $item["ujian_id"]; echo "' >
								
							</td>
						</tr>
						
							<td>jawaban_soal</td>
							<td>
							
									<input type='text' name='jawaban_soal' class='form-control' style='width:100%;' value='"; echo $item["jawaban_soal"]; echo "' >
								
							</td>
						</tr>
						
					"; 
				}
				echo "</table>";
			} // end view edit
			else if($_GET["act"] == "update"){
				
				$id = $this->input->post("id");
				$arrayPost = array(
				"soal" => $this->input->post("soal"),"a" => $this->input->post("a"),"b" => $this->input->post("b"),"c" => $this->input->post("c"),"d" => $this->input->post("d"),"e" => $this->input->post("e"),"ujian_id" => $this->input->post("ujian_id"),"jawaban_soal" => $this->input->post("jawaban_soal"),
				);
				$this->form_validation->set_rules("soal", "soal", "required");$this->form_validation->set_rules("a", "a", "required");$this->form_validation->set_rules("b", "b", "required");$this->form_validation->set_rules("c", "c", "required");$this->form_validation->set_rules("d", "d", "required");$this->form_validation->set_rules("e", "e", "required");$this->form_validation->set_rules("ujian_id", "ujian_id", "required");$this->form_validation->set_rules("jawaban_soal", "jawaban_soal", "required");
				if($this->form_validation->run() == true){
					$this->crud_function_model->updateData("bank_soal", $arrayPost, "id_bank_soal = '$id'");
					$message =  array(
					"message" => "Data Berhasil Di Simpan"
					);
				} else {
					$message =  array(
					"message" => validation_errors()
					);
				}
				$this->load->view("admin/valids/validationmessage", $message);
			
			}// end update 
			else if($_GET["act"] == "search"){
				$queryDataRead = array(
					"tampilData" => $this->crud_function_model->readData("bank_soal", "", "id_bank_soal like '%$_GET[id]%'  || soal like '%$_GET[id]%' || a like '%$_GET[id]%' || b like '%$_GET[id]%' || c like '%$_GET[id]%' || d like '%$_GET[id]%' || e like '%$_GET[id]%' || ujian_id like '%$_GET[id]%' || jawaban_soal like '%$_GET[id]%' ", "id_bank_soal desc"),
					"idDb" => "id_bank_soal"
				);
				$this->load->view("admin/content/bank_soal/table", $queryDataRead);
			}// end search
		}// end else // pertama
	}
}
			